# The Register — School Management App

A React Native (Expo) mobile app with three role-based panels — **Admin**, **Teacher**, and **Parent/Student** — for running a school: class/subject-teacher assignment, attendance, quizzes & tests, mid-terms, an academic calendar, a feedback system, and fee/salary tracking.

## Design identity

The visual language ("The Register") is built around a school ledger / attendance register book — ruled hairlines, a brass-gold index number on each list row, a warm ink-green and cream palette — instead of a generic blue/purple ed-tech look. See `src/theme/tokens.ts` for the full token system.

## Getting started

```bash
npm install
npx expo start
```

Then press `i` for iOS simulator, `a` for Android emulator, or scan the QR code with the Expo Go app on your phone.

## How role-based access works

There's no real backend yet — `src/context/AuthContext.tsx` provides a mock login. On the login screen, pick a role (Admin / Teacher / Parent), then pick a specific account. The app then routes to the matching navigator:

- `src/navigation/AdminNavigator.tsx`
- `src/navigation/TeacherNavigator.tsx`
- `src/navigation/ParentNavigator.tsx`

`src/navigation/RootNavigator.tsx` is the switch that decides which one to show based on `user.role`.

## Data layer — swapping in a real backend

Every screen calls functions from `src/services/api.ts`, never the mock data directly. Right now those functions read/write the in-memory arrays in `src/data/mockData.ts`. When you're ready to connect a real backend:

1. Keep the function signatures in `api.ts` the same.
2. Replace each function body with a `fetch()` call to your API.
3. No screen code needs to change.

You'll also want to swap `AuthContext`'s mock `login()` for a real authentication call (JWT, session cookie, Firebase Auth, etc.) at that point.

## Feature map

| Feature | Where it lives |
|---|---|
| One class teacher per class, separate subject teachers | `ManageTeachersScreen` (admin), `assignClassTeacher` / `assignSubjectTeacher` in `api.ts` |
| Attendance | `AttendanceScreen` (teacher, tap-to-cycle status), `AttendanceViewScreen` (parent) |
| Quizzes, tests, mid-terms | `QuizzesTestsScreen` (create), `TestRecordsScreen` (enter marks), `TestResultsScreen` (parent view) |
| Academic calendar | `src/screens/shared/AcademicCalendarScreen.tsx` — one screen, reused by all three panels, filtered by role/audience |
| Feedback system | `FeedbackScreen` (teacher), `FeedbackFormScreen` (parent), `FeedbackMonitorScreen` (admin oversight of all messages) |
| Fee management | `FeeManagementScreen` (admin), `FeeStatusScreen` (parent) |
| Salary management | `SalaryManagementScreen` (admin) |

## What's stubbed vs. production-ready

This scaffold is fully wired end-to-end with realistic mock data so every screen is interactive (mark attendance, assign teachers, enter marks, send feedback, mark fees/salaries paid). To take it to production you'll still want to add:

- A real backend + database (Postgres/Firebase/etc.) behind `api.ts`
- Real authentication (replacing the account picker on the login screen)
- Push notifications (e.g. new feedback, fee due reminders)
- Server-side validation and role permission checks (the client currently trusts the logged-in role)
- Persisted file storage if you add report cards, IDs, or document uploads

## Project structure

```
App.tsx
src/
  theme/tokens.ts        design tokens (color, type, spacing)
  types/index.ts          shared TypeScript types
  data/mockData.ts        seed data — swap for real API responses
  services/api.ts         the one seam between UI and data source
  context/AuthContext.tsx mock role-based auth
  navigation/              root + per-role stack navigators
  components/              LedgerRow, Badge, StatCard, SectionHeader, Button, ScreenContainer
  screens/
    auth/                  LoginScreen
    admin/                 dashboard, teacher/class assignment, fees, salaries, feedback inbox
    teacher/               dashboard, classes, attendance, quizzes/tests, test records, feedback
    parent/                dashboard, attendance view, test results, fee status, feedback form
    shared/                AcademicCalendarScreen (used by all three roles)
```
