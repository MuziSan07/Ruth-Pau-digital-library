import {
  Teacher,
  Student,
  Parent,
  SchoolClass,
  Subject,
  AttendanceRecord,
  Assessment,
  AssessmentResult,
  CalendarEvent,
  FeedbackEntry,
  FeeRecord,
  SalaryRecord,
  User,
} from '@/types';

export const subjects: Subject[] = [
  { id: 'sub-math', name: 'Mathematics' },
  { id: 'sub-sci', name: 'Science' },
  { id: 'sub-eng', name: 'English' },
  { id: 'sub-ss', name: 'Social Studies' },
  { id: 'sub-art', name: 'Art' },
];

export const admin: User = {
  id: 'admin-1',
  name: 'Naila Baig',
  role: 'admin',
  avatarInitials: 'NB',
  email: 'admin@theregister.school',
};

export const teachers: Teacher[] = [
  {
    id: 'teach-1',
    name: 'Imran Qureshi',
    role: 'teacher',
    avatarInitials: 'IQ',
    email: 'imran.q@theregister.school',
    subjectsTaught: ['sub-math', 'sub-sci'],
    isClassTeacherOf: 'class-8a',
    monthlySalary: 85000,
    salaryStatus: 'paid',
  },
  {
    id: 'teach-2',
    name: 'Ayesha Farooq',
    role: 'teacher',
    avatarInitials: 'AF',
    email: 'ayesha.f@theregister.school',
    subjectsTaught: ['sub-eng', 'sub-art'],
    isClassTeacherOf: 'class-8b',
    monthlySalary: 82000,
    salaryStatus: 'pending',
  },
  {
    id: 'teach-3',
    name: 'Bilal Hussain',
    role: 'teacher',
    avatarInitials: 'BH',
    email: 'bilal.h@theregister.school',
    subjectsTaught: ['sub-ss'],
    monthlySalary: 70000,
    salaryStatus: 'paid',
  },
  {
    id: 'teach-4',
    name: 'Sana Malik',
    role: 'teacher',
    avatarInitials: 'SM',
    email: 'sana.m@theregister.school',
    subjectsTaught: ['sub-math', 'sub-sci'],
    monthlySalary: 78000,
    salaryStatus: 'paid',
  },
];

export const classes: SchoolClass[] = [
  {
    id: 'class-8a',
    name: 'Grade 8 - A',
    classTeacherId: 'teach-1',
    subjectTeacherIds: {
      'sub-math': 'teach-1',
      'sub-sci': 'teach-4',
      'sub-eng': 'teach-2',
      'sub-ss': 'teach-3',
    },
    studentIds: ['stu-1', 'stu-2', 'stu-3', 'stu-4'],
  },
  {
    id: 'class-8b',
    name: 'Grade 8 - B',
    classTeacherId: 'teach-2',
    subjectTeacherIds: {
      'sub-math': 'teach-4',
      'sub-sci': 'teach-1',
      'sub-eng': 'teach-2',
      'sub-ss': 'teach-3',
    },
    studentIds: ['stu-5', 'stu-6', 'stu-7'],
  },
];

export const parents: Parent[] = [
  { id: 'par-1', name: 'Farhan Ali', role: 'parent', avatarInitials: 'FA', email: 'farhan.ali@mail.com', childIds: ['stu-1'] },
  { id: 'par-2', name: 'Nadia Sheikh', role: 'parent', avatarInitials: 'NS', email: 'nadia.s@mail.com', childIds: ['stu-2'] },
  { id: 'par-3', name: 'Waqas Ahmed', role: 'parent', avatarInitials: 'WA', email: 'waqas.a@mail.com', childIds: ['stu-5'] },
];

export const students: Student[] = [
  { id: 'stu-1', name: 'Zainab Ali', classId: 'class-8a', rollNo: 1, parentId: 'par-1', feeStatus: 'paid', feeAmountDue: 0 },
  { id: 'stu-2', name: 'Hassan Sheikh', classId: 'class-8a', rollNo: 2, parentId: 'par-2', feeStatus: 'due', feeAmountDue: 15000 },
  { id: 'stu-3', name: 'Mahnoor Iqbal', classId: 'class-8a', rollNo: 3, parentId: 'par-1', feeStatus: 'paid', feeAmountDue: 0 },
  { id: 'stu-4', name: 'Usman Tariq', classId: 'class-8a', rollNo: 4, parentId: 'par-2', feeStatus: 'overdue', feeAmountDue: 30000 },
  { id: 'stu-5', name: 'Areeba Waqas', classId: 'class-8b', rollNo: 1, parentId: 'par-3', feeStatus: 'paid', feeAmountDue: 0 },
  { id: 'stu-6', name: 'Danyal Khan', classId: 'class-8b', rollNo: 2, parentId: 'par-3', feeStatus: 'due', feeAmountDue: 15000 },
  { id: 'stu-7', name: 'Rimsha Aslam', classId: 'class-8b', rollNo: 3, parentId: 'par-3', feeStatus: 'paid', feeAmountDue: 0 },
];

export const attendanceRecords: AttendanceRecord[] = [
  {
    id: 'att-1',
    classId: 'class-8a',
    date: '2026-08-27',
    markedBy: 'teach-1',
    entries: { 'stu-1': 'present', 'stu-2': 'present', 'stu-3': 'absent', 'stu-4': 'late' },
  },
  {
    id: 'att-2',
    classId: 'class-8a',
    date: '2026-08-28',
    markedBy: 'teach-1',
    entries: { 'stu-1': 'present', 'stu-2': 'absent', 'stu-3': 'present', 'stu-4': 'present' },
  },
  {
    id: 'att-3',
    classId: 'class-8b',
    date: '2026-08-28',
    markedBy: 'teach-2',
    entries: { 'stu-5': 'present', 'stu-6': 'present', 'stu-7': 'excused' },
  },
];

export const assessments: Assessment[] = [
  { id: 'as-1', classId: 'class-8a', subjectId: 'sub-math', title: 'Algebra Quiz 3', type: 'quiz', date: '2026-08-20', maxMarks: 20, createdBy: 'teach-1' },
  { id: 'as-2', classId: 'class-8a', subjectId: 'sub-eng', title: 'Mid-Term Examination', type: 'midterm', date: '2026-09-15', maxMarks: 100, createdBy: 'teach-2' },
  { id: 'as-3', classId: 'class-8b', subjectId: 'sub-sci', title: 'Chapter 4 Test', type: 'test', date: '2026-08-22', maxMarks: 50, createdBy: 'teach-1' },
];

export const assessmentResults: AssessmentResult[] = [
  { assessmentId: 'as-1', studentId: 'stu-1', marksObtained: 18 },
  { assessmentId: 'as-1', studentId: 'stu-2', marksObtained: 14 },
  { assessmentId: 'as-1', studentId: 'stu-3', marksObtained: 20 },
  { assessmentId: 'as-1', studentId: 'stu-4', marksObtained: 11 },
  { assessmentId: 'as-3', studentId: 'stu-5', marksObtained: 41 },
  { assessmentId: 'as-3', studentId: 'stu-6', marksObtained: 33 },
  { assessmentId: 'as-3', studentId: 'stu-7', marksObtained: 47 },
];

export const calendarEvents: CalendarEvent[] = [
  { id: 'cal-1', title: 'Mid-Term Examinations Begin', date: '2026-09-15', category: 'exam', audience: 'all', description: 'All grades, 9:00 AM start.' },
  { id: 'cal-2', title: 'Parent-Teacher Meeting', date: '2026-09-05', category: 'meeting', audience: 'all' },
  { id: 'cal-3', title: 'Independence Day Holiday', date: '2026-08-14', category: 'holiday', audience: 'all' },
  { id: 'cal-4', title: 'Staff Development Day', date: '2026-09-01', category: 'event', audience: 'teacher' },
  { id: 'cal-5', title: 'Term 2 Fee Deadline', date: '2026-09-10', category: 'deadline', audience: 'parent' },
];

export const feedbackEntries: FeedbackEntry[] = [
  { id: 'fb-1', fromId: 'par-1', fromRole: 'parent', fromName: 'Farhan Ali', toRole: 'teacher', subject: 'Homework load', message: 'Zainab has been getting a lot of homework this week — is this expected before mid-terms?', date: '2026-08-25', status: 'open' },
  { id: 'fb-2', fromId: 'teach-1', fromRole: 'teacher', fromName: 'Imran Qureshi', toRole: 'admin', subject: 'Lab equipment request', message: 'Grade 8-A needs new microscopes for the science unit next month.', date: '2026-08-24', status: 'reviewed' },
];

export const feeRecords: FeeRecord[] = [
  { id: 'fee-1', studentId: 'stu-2', term: 'Term 2', amount: 15000, status: 'due', dueDate: '2026-09-10' },
  { id: 'fee-2', studentId: 'stu-4', term: 'Term 1', amount: 30000, status: 'overdue', dueDate: '2026-08-01' },
  { id: 'fee-3', studentId: 'stu-6', term: 'Term 2', amount: 15000, status: 'due', dueDate: '2026-09-10' },
];

export const salaryRecords: SalaryRecord[] = [
  { id: 'sal-1', teacherId: 'teach-1', month: 'August 2026', amount: 85000, status: 'paid' },
  { id: 'sal-2', teacherId: 'teach-2', month: 'August 2026', amount: 82000, status: 'pending' },
  { id: 'sal-3', teacherId: 'teach-3', month: 'August 2026', amount: 70000, status: 'paid' },
  { id: 'sal-4', teacherId: 'teach-4', month: 'August 2026', amount: 78000, status: 'paid' },
];
