/**
 * Design language: "The Register"
 * Inspired by a school ledger / attendance register book — ruled lines,
 * ink, brass tabs — rather than generic ed-tech blue/purple card UI.
 */

export const colors = {
  ink: '#1F3D2B',       // deep forest ink — primary, headers, active states
  inkSoft: '#2E5340',   // lighter ink for pressed/secondary primary
  paper: '#FAF6EE',     // warm cream page background
  paperDim: '#F1EBDD',  // slightly deeper paper for input fields
  sage: '#E4E9DE',      // secondary surface / chips / dividunderstated fills
  gold: '#C99A3E',      // brass accent — active tab, ledger index numbers
  goldSoft: '#EADDBB',  // gold tint for badges
  slate: '#2B2B28',     // primary text (warm near-black, not pure black)
  slateMuted: '#6B6559',// secondary text
  rust: '#B14A34',      // absence / overdue / error
  rustSoft: '#F3DCD5',  // rust tint background
  moss: '#4C7A5A',      // present / paid / success
  mossSoft: '#DCE8DE',  // moss tint background
  rule: '#D8D0BC',      // hairline rule color (like ruled paper lines)
  white: '#FFFFFF',
};

export const roleAccents = {
  admin: colors.gold,
  teacher: colors.moss,
  parent: colors.rust,
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

export const radius = {
  sm: 4,
  md: 8,
  lg: 14,
  pill: 999,
};

export const type = {
  display: 'Fraunces_600SemiBold',
  displayItalic: 'Fraunces_500Medium_Italic',
  body: 'Inter_400Regular',
  bodyMedium: 'Inter_500Medium',
  bodySemiBold: 'Inter_600SemiBold',
  mono: 'IBMPlexMono_500Medium',
  monoRegular: 'IBMPlexMono_400Regular',
};

export const fontSize = {
  xs: 12,
  sm: 13,
  md: 15,
  lg: 18,
  xl: 22,
  xxl: 28,
  display: 34,
};

export default { colors, roleAccents, spacing, radius, type, fontSize };
