import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { useAuth } from '@/context/AuthContext';
import { LoginScreen } from '@/screens/auth/LoginScreen';
import { AdminNavigator } from './AdminNavigator';
import { TeacherNavigator } from './TeacherNavigator';
import { ParentNavigator } from './ParentNavigator';

export const RootNavigator: React.FC = () => {
  const { user } = useAuth();

  return (
    <NavigationContainer>
      {!user && <LoginScreen />}
      {user?.role === 'admin' && <AdminNavigator />}
      {user?.role === 'teacher' && <TeacherNavigator />}
      {user?.role === 'parent' && <ParentNavigator />}
    </NavigationContainer>
  );
};
