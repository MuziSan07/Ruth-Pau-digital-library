import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AdminDashboard } from '@/screens/admin/AdminDashboard';
import { ManageTeachersScreen } from '@/screens/admin/ManageTeachersScreen';
import { FeeManagementScreen } from '@/screens/admin/FeeManagementScreen';
import { SalaryManagementScreen } from '@/screens/admin/SalaryManagementScreen';
import { FeedbackMonitorScreen } from '@/screens/admin/FeedbackMonitorScreen';
import { AcademicCalendarScreen } from '@/screens/shared/AcademicCalendarScreen';
import { colors, type } from '@/theme/tokens';

const Stack = createNativeStackNavigator();

const screenOptions = {
  headerStyle: { backgroundColor: colors.paper },
  headerTintColor: colors.ink,
  headerTitleStyle: { fontFamily: type.bodySemiBold },
  headerShadowVisible: false,
};

export const AdminNavigator: React.FC = () => (
  <Stack.Navigator screenOptions={screenOptions}>
    <Stack.Screen name="AdminHome" component={AdminDashboard} options={{ title: 'The Register' }} />
    <Stack.Screen name="ManageTeachers" component={ManageTeachersScreen} options={{ title: 'Teachers & Classes' }} />
    <Stack.Screen name="FeeManagement" component={FeeManagementScreen} options={{ title: 'Fee Management' }} />
    <Stack.Screen name="SalaryManagement" component={SalaryManagementScreen} options={{ title: 'Salary Management' }} />
    <Stack.Screen name="FeedbackMonitor" component={FeedbackMonitorScreen} options={{ title: 'Feedback Inbox' }} />
    <Stack.Screen name="AcademicCalendar" component={AcademicCalendarScreen} options={{ title: 'Academic Calendar' }} />
  </Stack.Navigator>
);
