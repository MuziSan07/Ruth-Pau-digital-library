import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ParentDashboard } from '@/screens/parent/ParentDashboard';
import { AttendanceViewScreen } from '@/screens/parent/AttendanceViewScreen';
import { TestResultsScreen } from '@/screens/parent/TestResultsScreen';
import { FeeStatusScreen } from '@/screens/parent/FeeStatusScreen';
import { FeedbackFormScreen } from '@/screens/parent/FeedbackFormScreen';
import { AcademicCalendarScreen } from '@/screens/shared/AcademicCalendarScreen';
import { colors, type } from '@/theme/tokens';

const Stack = createNativeStackNavigator();

const screenOptions = {
  headerStyle: { backgroundColor: colors.paper },
  headerTintColor: colors.ink,
  headerTitleStyle: { fontFamily: type.bodySemiBold },
  headerShadowVisible: false,
};

export const ParentNavigator: React.FC = () => (
  <Stack.Navigator screenOptions={screenOptions}>
    <Stack.Screen name="ParentHome" component={ParentDashboard} options={{ title: 'The Register' }} />
    <Stack.Screen name="AttendanceView" component={AttendanceViewScreen} options={{ title: 'Attendance' }} />
    <Stack.Screen name="TestResults" component={TestResultsScreen} options={{ title: 'Test Results' }} />
    <Stack.Screen name="FeeStatus" component={FeeStatusScreen} options={{ title: 'Fee Status' }} />
    <Stack.Screen name="FeedbackForm" component={FeedbackFormScreen} options={{ title: 'Feedback' }} />
    <Stack.Screen name="AcademicCalendar" component={AcademicCalendarScreen} options={{ title: 'Academic Calendar' }} />
  </Stack.Navigator>
);
