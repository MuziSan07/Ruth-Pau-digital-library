import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { TeacherDashboard } from '@/screens/teacher/TeacherDashboard';
import { MyClassesScreen } from '@/screens/teacher/MyClassesScreen';
import { AttendanceScreen } from '@/screens/teacher/AttendanceScreen';
import { QuizzesTestsScreen } from '@/screens/teacher/QuizzesTestsScreen';
import { TestRecordsScreen } from '@/screens/teacher/TestRecordsScreen';
import { FeedbackScreen } from '@/screens/teacher/FeedbackScreen';
import { AcademicCalendarScreen } from '@/screens/shared/AcademicCalendarScreen';
import { colors, type } from '@/theme/tokens';

const Stack = createNativeStackNavigator();

const screenOptions = {
  headerStyle: { backgroundColor: colors.paper },
  headerTintColor: colors.ink,
  headerTitleStyle: { fontFamily: type.bodySemiBold },
  headerShadowVisible: false,
};

export const TeacherNavigator: React.FC = () => (
  <Stack.Navigator screenOptions={screenOptions}>
    <Stack.Screen name="TeacherHome" component={TeacherDashboard} options={{ title: 'The Register' }} />
    <Stack.Screen name="MyClasses" component={MyClassesScreen} options={{ title: 'My Classes' }} />
    <Stack.Screen name="Attendance" component={AttendanceScreen} options={{ title: 'Attendance' }} />
    <Stack.Screen name="QuizzesTests" component={QuizzesTestsScreen} options={{ title: 'Quizzes & Tests' }} />
    <Stack.Screen name="TestRecords" component={TestRecordsScreen} options={{ title: 'Test Records' }} />
    <Stack.Screen name="Feedback" component={FeedbackScreen} options={{ title: 'Feedback' }} />
    <Stack.Screen name="AcademicCalendar" component={AcademicCalendarScreen} options={{ title: 'Academic Calendar' }} />
  </Stack.Navigator>
);
