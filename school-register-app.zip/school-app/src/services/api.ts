/**
 * This is the single seam between the UI and your data source.
 * Every function here currently reads/writes the in-memory mock arrays.
 * To connect a real backend, replace the bodies of these functions with
 * `fetch(...)` calls to your API — screens never need to change.
 */
import * as db from '@/data/mockData';
import {
  AttendanceRecord,
  AttendanceStatus,
  Assessment,
  AssessmentResult,
  FeedbackEntry,
  Role,
} from '@/types';

// ---------- People & structure ----------
export const getAdmin = () => db.admin;
export const getTeachers = () => db.teachers;
export const getTeacherById = (id: string) => db.teachers.find((t) => t.id === id);
export const getParents = () => db.parents;
export const getParentById = (id: string) => db.parents.find((p) => p.id === id);
export const getStudents = () => db.students;
export const getStudentById = (id: string) => db.students.find((s) => s.id === id);
export const getStudentsByClass = (classId: string) =>
  db.students.filter((s) => s.classId === classId);
export const getChildrenOfParent = (parentId: string) => {
  const parent = getParentById(parentId);
  return parent ? db.students.filter((s) => parent.childIds.includes(s.id)) : [];
};
export const getClasses = () => db.classes;
export const getClassById = (id: string) => db.classes.find((c) => c.id === id);
export const getClassTaughtByTeacherAsClassTeacher = (teacherId: string) =>
  db.classes.find((c) => c.classTeacherId === teacherId);
export const getClassesTeacherTeachesIn = (teacherId: string) =>
  db.classes.filter((c) => Object.values(c.subjectTeacherIds).includes(teacherId));
export const getSubjects = () => db.subjects;
export const getSubjectById = (id: string) => db.subjects.find((s) => s.id === id);
export const assignClassTeacher = (classId: string, teacherId: string) => {
  // A class has exactly one class teacher — clear any previous class-teacher
  // assignment that teacher held elsewhere, then assign them here.
  db.teachers.forEach((t) => {
    if (t.isClassTeacherOf === classId) t.isClassTeacherOf = undefined;
  });
  const previousTeacherId = getClassById(classId)?.classTeacherId;
  const previousTeacher = previousTeacherId ? getTeacherById(previousTeacherId) : undefined;
  if (previousTeacher && previousTeacher.isClassTeacherOf === classId) {
    previousTeacher.isClassTeacherOf = undefined;
  }
  const cls = getClassById(classId);
  if (cls) cls.classTeacherId = teacherId;
  const newTeacher = getTeacherById(teacherId);
  if (newTeacher) newTeacher.isClassTeacherOf = classId;
};

export const assignSubjectTeacher = (classId: string, subjectId: string, teacherId: string) => {
  const cls = getClassById(classId);
  if (cls) cls.subjectTeacherIds[subjectId] = teacherId;
};

export const getSubjectsForTeacherInClass = (teacherId: string, classId: string) => {
  const cls = getClassById(classId);
  if (!cls) return [];
  return Object.entries(cls.subjectTeacherIds)
    .filter(([, tId]) => tId === teacherId)
    .map(([subId]) => getSubjectById(subId)!)
    .filter(Boolean);
};

// ---------- Attendance ----------
export const getAttendanceForClass = (classId: string) =>
  db.attendanceRecords.filter((a) => a.classId === classId).sort((a, b) => (a.date < b.date ? 1 : -1));

export const getAttendanceForStudent = (studentId: string) =>
  db.attendanceRecords
    .filter((a) => studentId in a.entries)
    .map((a) => ({ date: a.date, status: a.entries[studentId] }))
    .sort((a, b) => (a.date < b.date ? 1 : -1));

export const submitAttendance = (
  classId: string,
  date: string,
  markedBy: string,
  entries: Record<string, AttendanceStatus>
): AttendanceRecord => {
  const record: AttendanceRecord = { id: `att-${Date.now()}`, classId, date, markedBy, entries };
  db.attendanceRecords.unshift(record);
  return record;
};

export const attendancePercentageForStudent = (studentId: string) => {
  const records = getAttendanceForStudent(studentId);
  if (records.length === 0) return null;
  const present = records.filter((r) => r.status === 'present' || r.status === 'late').length;
  return Math.round((present / records.length) * 100);
};

// ---------- Assessments (quizzes / tests / mid-terms) ----------
export const getAssessmentsForClass = (classId: string) =>
  db.assessments.filter((a) => a.classId === classId).sort((a, b) => (a.date < b.date ? 1 : -1));

export const getAssessmentsForStudent = (studentId: string) => {
  const student = getStudentById(studentId);
  if (!student) return [];
  return getAssessmentsForClass(student.classId);
};

export const getResultsForAssessment = (assessmentId: string) =>
  db.assessmentResults.filter((r) => r.assessmentId === assessmentId);

export const getResultForStudent = (assessmentId: string, studentId: string) =>
  db.assessmentResults.find((r) => r.assessmentId === assessmentId && r.studentId === studentId);

export const createAssessment = (assessment: Omit<Assessment, 'id'>): Assessment => {
  const created: Assessment = { ...assessment, id: `as-${Date.now()}` };
  db.assessments.push(created);
  return created;
};

export const recordResult = (result: AssessmentResult) => {
  const existing = getResultForStudent(result.assessmentId, result.studentId);
  if (existing) {
    existing.marksObtained = result.marksObtained;
  } else {
    db.assessmentResults.push(result);
  }
};

// ---------- Academic calendar ----------
export const getCalendarEvents = (forRole?: Role) =>
  db.calendarEvents
    .filter((e) => !forRole || e.audience === 'all' || e.audience === forRole)
    .sort((a, b) => (a.date > b.date ? 1 : -1));

// ---------- Feedback ----------
export const getFeedbackForRole = (role: Role) =>
  db.feedbackEntries.filter((f) => f.toRole === role || f.toRole === 'all').sort((a, b) => (a.date < b.date ? 1 : -1));

export const getFeedbackFrom = (userId: string) =>
  db.feedbackEntries.filter((f) => f.fromId === userId).sort((a, b) => (a.date < b.date ? 1 : -1));

export const getAllFeedback = () => [...db.feedbackEntries].sort((a, b) => (a.date < b.date ? 1 : -1));

export const submitFeedback = (entry: Omit<FeedbackEntry, 'id' | 'status' | 'date'>): FeedbackEntry => {
  const created: FeedbackEntry = {
    ...entry,
    id: `fb-${Date.now()}`,
    status: 'open',
    date: new Date().toISOString().slice(0, 10),
  };
  db.feedbackEntries.unshift(created);
  return created;
};

export const markFeedbackReviewed = (id: string) => {
  const entry = db.feedbackEntries.find((f) => f.id === id);
  if (entry) entry.status = 'reviewed';
};

// ---------- Fees ----------
export const getFeeRecords = () => db.feeRecords;
export const getFeeRecordsForStudent = (studentId: string) =>
  db.feeRecords.filter((f) => f.studentId === studentId);
export const markFeePaid = (feeId: string) => {
  const record = db.feeRecords.find((f) => f.id === feeId);
  if (record) record.status = 'paid';
  const student = record && getStudentById(record.studentId);
  if (student) {
    student.feeStatus = 'paid';
    student.feeAmountDue = 0;
  }
};

// ---------- Salaries ----------
export const getSalaryRecords = () => db.salaryRecords;
export const getSalaryRecordsForTeacher = (teacherId: string) =>
  db.salaryRecords.filter((s) => s.teacherId === teacherId);
export const markSalaryPaid = (salaryId: string) => {
  const record = db.salaryRecords.find((s) => s.id === salaryId);
  if (record) record.status = 'paid';
  const teacher = record && getTeacherById(record.teacherId);
  if (teacher) teacher.salaryStatus = 'paid';
};
