import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { Button } from '@/components/Button';
import { colors, type, fontSize, radius, spacing, roleAccents } from '@/theme/tokens';
import { Role } from '@/types';
import { useAuth } from '@/context/AuthContext';
import * as api from '@/services/api';

const ROLES: { key: Role; label: string; sub: string }[] = [
  { key: 'admin', label: 'Admin', sub: 'Run the school' },
  { key: 'teacher', label: 'Teacher', sub: 'Run the classroom' },
  { key: 'parent', label: 'Parent / Student', sub: 'Follow along' },
];

export const LoginScreen: React.FC = () => {
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const { login } = useAuth();

  const teachers = api.getTeachers();
  const parents = api.getParents();

  return (
    <ScreenContainer>
      <View style={styles.header}>
        <Text style={styles.eyebrow}>THE REGISTER</Text>
        <Text style={styles.title}>Sign in to your{'\n'}school ledger</Text>
      </View>

      <View style={styles.roleGrid}>
        {ROLES.map((r) => {
          const active = selectedRole === r.key;
          return (
            <TouchableOpacity
              key={r.key}
              style={[styles.roleCard, active && { borderColor: roleAccents[r.key] }]}
              onPress={() => setSelectedRole(r.key)}
              activeOpacity={0.8}
            >
              <View style={[styles.roleDot, { backgroundColor: roleAccents[r.key] }]} />
              <Text style={styles.roleLabel}>{r.label}</Text>
              <Text style={styles.roleSub}>{r.sub}</Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {selectedRole === 'admin' && (
        <View style={styles.pickerSection}>
          <Text style={styles.pickerLabel}>Continue as the school admin</Text>
          <Button label="Enter Admin Panel" onPress={() => login('admin', 'admin-1')} />
        </View>
      )}

      {selectedRole === 'teacher' && (
        <View style={styles.pickerSection}>
          <Text style={styles.pickerLabel}>Choose a teacher account</Text>
          {teachers.map((t) => (
            <TouchableOpacity key={t.id} style={styles.pickRow} onPress={() => login('teacher', t.id)}>
              <Text style={styles.pickName}>{t.name}</Text>
              <Text style={styles.pickMeta}>
                {t.isClassTeacherOf ? 'Class Teacher' : 'Subject Teacher'} →
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {selectedRole === 'parent' && (
        <View style={styles.pickerSection}>
          <Text style={styles.pickerLabel}>Choose a parent account</Text>
          {parents.map((p) => (
            <TouchableOpacity key={p.id} style={styles.pickRow} onPress={() => login('parent', p.id)}>
              <Text style={styles.pickName}>{p.name}</Text>
              <Text style={styles.pickMeta}>→</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  header: { marginTop: spacing.xxl, marginBottom: spacing.xl },
  eyebrow: { fontFamily: type.mono, fontSize: 12, letterSpacing: 2, color: colors.gold },
  title: { fontFamily: type.display, fontSize: fontSize.display, color: colors.ink, marginTop: spacing.sm, lineHeight: 40 },
  roleGrid: { flexDirection: 'row', gap: spacing.sm },
  roleCard: {
    flex: 1,
    backgroundColor: colors.white,
    borderWidth: 1.5,
    borderColor: colors.rule,
    borderRadius: radius.lg,
    padding: spacing.md,
  },
  roleDot: { width: 10, height: 10, borderRadius: 5, marginBottom: spacing.sm },
  roleLabel: { fontFamily: type.bodySemiBold, fontSize: fontSize.sm, color: colors.slate },
  roleSub: { fontFamily: type.body, fontSize: 11, color: colors.slateMuted, marginTop: 2 },
  pickerSection: { marginTop: spacing.xl },
  pickerLabel: { fontFamily: type.bodyMedium, fontSize: fontSize.sm, color: colors.slateMuted, marginBottom: spacing.sm },
  pickRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.rule,
  },
  pickName: { fontFamily: type.bodyMedium, fontSize: fontSize.md, color: colors.slate },
  pickMeta: { fontFamily: type.mono, fontSize: fontSize.xs, color: colors.gold },
});
