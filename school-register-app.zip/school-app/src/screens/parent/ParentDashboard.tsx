import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { StatCard } from '@/components/StatCard';
import { LedgerRow } from '@/components/LedgerRow';
import { Badge } from '@/components/Badge';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import { useAuth } from '@/context/AuthContext';
import * as api from '@/services/api';
import { useNavigation } from '@react-navigation/native';

export const ParentDashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const navigation = useNavigation<any>();
  const children = api.getChildrenOfParent(user!.id);
  const [childId, setChildId] = useState(children[0]?.id);
  const child = children.find((c) => c.id === childId);

  if (!child) {
    return (
      <ScreenContainer>
        <Text style={styles.title}>No student record linked to this account.</Text>
      </ScreenContainer>
    );
  }

  const attendancePct = api.attendancePercentageForStudent(child.id);
  const cls = api.getClassById(child.classId);
  const assessments = api.getAssessmentsForStudent(child.id);
  const latestResult = assessments
    .map((a) => ({ a, r: api.getResultForStudent(a.id, child.id) }))
    .filter((x) => x.r)
    .slice(-1)[0];

  const links = [
    { label: 'Attendance', screen: 'AttendanceView' },
    { label: 'Test Results', screen: 'TestResults' },
    { label: 'Fee Status', screen: 'FeeStatus' },
    { label: 'Academic Calendar', screen: 'AcademicCalendar' },
    { label: 'Feedback', screen: 'FeedbackForm' },
  ];

  return (
    <ScreenContainer>
      <View style={styles.header}>
        <Text style={styles.eyebrow}>PARENT PANEL</Text>
        <Text style={styles.title}>Welcome, {user?.name.split(' ')[0]}</Text>
      </View>

      {children.length > 1 && (
        <View style={styles.chipRow}>
          {children.map((c) => (
            <TouchableOpacity key={c.id} style={[styles.chip, c.id === childId && styles.chipActive]} onPress={() => setChildId(c.id)}>
              <Text style={[styles.chipText, c.id === childId && styles.chipTextActive]}>{c.name.split(' ')[0]}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <View style={styles.childBanner}>
        <Text style={styles.childName}>{child.name}</Text>
        <Text style={styles.childMeta}>{cls?.name} · Roll No. {child.rollNo}</Text>
      </View>

      <View style={styles.statsRow}>
        <StatCard label="Attendance" value={attendancePct !== null ? `${attendancePct}%` : '—'} accent={attendancePct !== null && attendancePct < 75 ? colors.rust : colors.moss} />
        <StatCard label="Fee status" value={child.feeStatus} accent={child.feeStatus === 'paid' ? colors.moss : colors.rust} />
      </View>

      {latestResult && (
        <View style={styles.card}>
          <LedgerRow
            title={latestResult.a.title}
            subtitle={`${api.getSubjectById(latestResult.a.subjectId)?.name} · Latest result`}
            right={<Text style={styles.score}>{latestResult.r!.marksObtained}/{latestResult.a.maxMarks}</Text>}
            style={{ borderBottomWidth: 0 }}
          />
        </View>
      )}

      <SectionHeader eyebrow="Follow along" title="Explore" />
      <View style={styles.card}>
        {links.map((l, i) => (
          <LedgerRow key={l.screen} index={i + 1} title={l.label} onPress={() => navigation.navigate(l.screen)} style={i === links.length - 1 ? { borderBottomWidth: 0 } : undefined} />
        ))}
      </View>

      <TouchableOpacity style={styles.logout} onPress={logout}>
        <Text style={styles.logoutText}>Sign out</Text>
      </TouchableOpacity>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  header: { marginTop: spacing.lg, marginBottom: spacing.md },
  eyebrow: { fontFamily: type.mono, fontSize: 11, letterSpacing: 1.5, color: colors.rust },
  title: { fontFamily: type.display, fontSize: fontSize.xxl, color: colors.ink, marginTop: 4 },
  chipRow: { flexDirection: 'row', gap: spacing.xs, marginBottom: spacing.sm },
  chip: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.pill, backgroundColor: colors.sage },
  chipActive: { backgroundColor: colors.ink },
  chipText: { fontFamily: type.bodyMedium, fontSize: fontSize.xs, color: colors.slate },
  chipTextActive: { color: colors.paper },
  childBanner: { backgroundColor: colors.rustSoft, borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.sm },
  childName: { fontFamily: type.display, fontSize: fontSize.lg, color: colors.rust },
  childMeta: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, marginTop: 2 },
  statsRow: { flexDirection: 'row', marginBottom: spacing.sm },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md, marginBottom: spacing.sm },
  score: { fontFamily: type.mono, fontSize: fontSize.md, color: colors.ink },
  logout: { marginTop: spacing.xl, alignItems: 'center', paddingVertical: spacing.md },
  logoutText: { fontFamily: type.bodyMedium, color: colors.rust, fontSize: fontSize.sm },
});
