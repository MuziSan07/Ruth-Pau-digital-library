import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { LedgerRow } from '@/components/LedgerRow';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import { useAuth } from '@/context/AuthContext';
import * as api from '@/services/api';

export const TestResultsScreen: React.FC = () => {
  const { user } = useAuth();
  const children = api.getChildrenOfParent(user!.id);
  const [childId, setChildId] = useState(children[0]?.id);
  const child = children.find((c) => c.id === childId)!;
  const assessments = api.getAssessmentsForStudent(child.id);

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="Parent" title="Test Results" />

      {children.length > 1 && (
        <View style={styles.chipRow}>
          {children.map((c) => (
            <TouchableOpacity key={c.id} style={[styles.chip, c.id === childId && styles.chipActive]} onPress={() => setChildId(c.id)}>
              <Text style={[styles.chipText, c.id === childId && styles.chipTextActive]}>{c.name.split(' ')[0]}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <View style={styles.card}>
        {assessments.map((a, i) => {
          const result = api.getResultForStudent(a.id, child.id);
          return (
            <LedgerRow
              key={a.id}
              index={i + 1}
              title={a.title}
              subtitle={`${api.getSubjectById(a.subjectId)?.name} · ${a.type.toUpperCase()} · ${a.date}`}
              right={
                <Text style={styles.score}>
                  {result ? `${result.marksObtained}/${a.maxMarks}` : 'Pending'}
                </Text>
              }
              style={i === assessments.length - 1 ? { borderBottomWidth: 0 } : undefined}
            />
          );
        })}
        {assessments.length === 0 && <Text style={styles.empty}>No assessments recorded yet.</Text>}
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  chipRow: { flexDirection: 'row', gap: spacing.xs, marginBottom: spacing.sm },
  chip: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.pill, backgroundColor: colors.sage },
  chipActive: { backgroundColor: colors.ink },
  chipText: { fontFamily: type.bodyMedium, fontSize: fontSize.xs, color: colors.slate },
  chipTextActive: { color: colors.paper },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md },
  score: { fontFamily: type.mono, fontSize: fontSize.sm, color: colors.ink },
  empty: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, paddingVertical: spacing.lg, textAlign: 'center' },
});
