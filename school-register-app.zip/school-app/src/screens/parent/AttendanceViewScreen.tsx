import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { Badge } from '@/components/Badge';
import { StatCard } from '@/components/StatCard';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import { useAuth } from '@/context/AuthContext';
import * as api from '@/services/api';

export const AttendanceViewScreen: React.FC = () => {
  const { user } = useAuth();
  const children = api.getChildrenOfParent(user!.id);
  const [childId, setChildId] = useState(children[0]?.id);
  const child = children.find((c) => c.id === childId)!;
  const history = api.getAttendanceForStudent(child.id);
  const pct = api.attendancePercentageForStudent(child.id);

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="Parent" title="Attendance" />

      {children.length > 1 && (
        <View style={styles.chipRow}>
          {children.map((c) => (
            <TouchableOpacity key={c.id} style={[styles.chip, c.id === childId && styles.chipActive]} onPress={() => setChildId(c.id)}>
              <Text style={[styles.chipText, c.id === childId && styles.chipTextActive]}>{c.name.split(' ')[0]}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <StatCard label={`${child.name.split(' ')[0]}'s attendance rate`} value={pct !== null ? `${pct}%` : 'No data'} accent={pct !== null && pct < 75 ? colors.rust : colors.moss} />

      <SectionHeader title="Day by day" />
      <View style={styles.card}>
        {history.map((h, i) => (
          <View key={h.date} style={[styles.row, i === history.length - 1 && { borderBottomWidth: 0 }]}>
            <Text style={styles.date}>{h.date}</Text>
            <Badge label={h.status} />
          </View>
        ))}
        {history.length === 0 && <Text style={styles.empty}>No attendance records yet.</Text>}
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  chipRow: { flexDirection: 'row', gap: spacing.xs, marginBottom: spacing.sm },
  chip: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.pill, backgroundColor: colors.sage },
  chipActive: { backgroundColor: colors.ink },
  chipText: { fontFamily: type.bodyMedium, fontSize: fontSize.xs, color: colors.slate },
  chipTextActive: { color: colors.paper },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md, marginTop: spacing.sm },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.rule },
  date: { fontFamily: type.mono, fontSize: fontSize.sm, color: colors.slate },
  empty: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, paddingVertical: spacing.lg, textAlign: 'center' },
});
