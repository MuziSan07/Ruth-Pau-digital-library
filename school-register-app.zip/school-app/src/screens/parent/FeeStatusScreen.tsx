import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { Badge } from '@/components/Badge';
import { Button } from '@/components/Button';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import { useAuth } from '@/context/AuthContext';
import * as api from '@/services/api';

export const FeeStatusScreen: React.FC = () => {
  const { user } = useAuth();
  const [, forceRerender] = useState(0);
  const children = api.getChildrenOfParent(user!.id);
  const [childId, setChildId] = useState(children[0]?.id);
  const child = children.find((c) => c.id === childId)!;
  const records = api.getFeeRecordsForStudent(child.id);

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="Parent" title="Fee Status" />

      {children.length > 1 && (
        <View style={styles.chipRow}>
          {children.map((c) => (
            <TouchableOpacity key={c.id} style={[styles.chip, c.id === childId && styles.chipActive]} onPress={() => setChildId(c.id)}>
              <Text style={[styles.chipText, c.id === childId && styles.chipTextActive]}>{c.name.split(' ')[0]}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <View style={styles.summary}>
        <Text style={styles.summaryLabel}>Current status</Text>
        <Badge label={child.feeStatus} />
      </View>
      {child.feeAmountDue > 0 && <Text style={styles.due}>Rs {child.feeAmountDue.toLocaleString()} due</Text>}

      <SectionHeader title="Records" />
      <View style={styles.card}>
        {records.map((r, i) => (
          <View key={r.id} style={[styles.row, i === records.length - 1 && { borderBottomWidth: 0 }]}>
            <View>
              <Text style={styles.term}>{r.term}</Text>
              <Text style={styles.due2}>Due {r.dueDate}</Text>
            </View>
            <View style={{ alignItems: 'flex-end', gap: 6 }}>
              <Text style={styles.amount}>Rs {r.amount.toLocaleString()}</Text>
              <Badge label={r.status} />
            </View>
          </View>
        ))}
        {records.length === 0 && <Text style={styles.empty}>No outstanding fee records — you're all caught up.</Text>}
      </View>

      {records.some((r) => r.status !== 'paid') && (
        <Button
          label="Simulate Payment (Demo)"
          onPress={() => {
            records.forEach((r) => {
              if (r.status !== 'paid') api.markFeePaid(r.id);
            });
            forceRerender((n) => n + 1);
          }}
          style={{ marginTop: spacing.md }}
        />
      )}
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  chipRow: { flexDirection: 'row', gap: spacing.xs, marginBottom: spacing.sm },
  chip: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.pill, backgroundColor: colors.sage },
  chipActive: { backgroundColor: colors.ink },
  chipText: { fontFamily: type.bodyMedium, fontSize: fontSize.xs, color: colors.slate },
  chipTextActive: { color: colors.paper },
  summary: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, padding: spacing.md },
  summaryLabel: { fontFamily: type.bodyMedium, fontSize: fontSize.md, color: colors.slate },
  due: { fontFamily: type.mono, fontSize: fontSize.sm, color: colors.rust, marginTop: spacing.xs },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.rule },
  term: { fontFamily: type.bodyMedium, fontSize: fontSize.md, color: colors.slate },
  due2: { fontFamily: type.body, fontSize: fontSize.xs, color: colors.slateMuted, marginTop: 2 },
  amount: { fontFamily: type.mono, fontSize: fontSize.sm, color: colors.ink },
  empty: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, paddingVertical: spacing.lg, textAlign: 'center' },
});
