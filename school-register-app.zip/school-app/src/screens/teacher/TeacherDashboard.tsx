import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { StatCard } from '@/components/StatCard';
import { LedgerRow } from '@/components/LedgerRow';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import { useAuth } from '@/context/AuthContext';
import * as api from '@/services/api';
import { useNavigation } from '@react-navigation/native';

export const TeacherDashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const navigation = useNavigation<any>();
  const teacher = api.getTeacherById(user!.id)!;
  const classTeacherOf = teacher.isClassTeacherOf ? api.getClassById(teacher.isClassTeacherOf) : undefined;
  const classesTeaching = api.getClassesTeacherTeachesIn(teacher.id);

  const links = [
    { label: 'Take Attendance', screen: 'Attendance' },
    { label: 'Quizzes & Tests', screen: 'QuizzesTests' },
    { label: 'Test Records', screen: 'TestRecords' },
    { label: 'My Classes', screen: 'MyClasses' },
    { label: 'Academic Calendar', screen: 'AcademicCalendar' },
    { label: 'Feedback', screen: 'Feedback' },
  ];

  return (
    <ScreenContainer>
      <View style={styles.header}>
        <Text style={styles.eyebrow}>TEACHER PANEL</Text>
        <Text style={styles.title}>Welcome, {user?.name.split(' ')[0]}</Text>
      </View>

      <View style={styles.statsRow}>
        <StatCard label="Subjects taught" value={String(teacher.subjectsTaught.length)} />
        <StatCard label="Classes involved" value={String(classesTeaching.length)} />
        <StatCard label="Salary" value={teacher.salaryStatus === 'paid' ? 'Paid' : 'Pending'} accent={teacher.salaryStatus === 'paid' ? colors.moss : colors.gold} />
      </View>

      <View style={styles.roleBanner}>
        <Text style={styles.roleBannerText}>
          {classTeacherOf
            ? `You are the Class Teacher of ${classTeacherOf.name}`
            : 'You are a Subject Teacher — no homeroom class assigned'}
        </Text>
      </View>

      <SectionHeader eyebrow="Workflow" title="Quick actions" />
      <View style={styles.card}>
        {links.map((l, i) => (
          <LedgerRow
            key={l.screen}
            index={i + 1}
            title={l.label}
            onPress={() => navigation.navigate(l.screen)}
            style={i === links.length - 1 ? { borderBottomWidth: 0 } : undefined}
          />
        ))}
      </View>

      <TouchableOpacity style={styles.logout} onPress={logout}>
        <Text style={styles.logoutText}>Sign out</Text>
      </TouchableOpacity>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  header: { marginTop: spacing.lg, marginBottom: spacing.md },
  eyebrow: { fontFamily: type.mono, fontSize: 11, letterSpacing: 1.5, color: colors.moss },
  title: { fontFamily: type.display, fontSize: fontSize.xxl, color: colors.ink, marginTop: 4 },
  statsRow: { flexDirection: 'row', marginTop: spacing.sm },
  roleBanner: { backgroundColor: colors.mossSoft, borderRadius: radius.md, padding: spacing.md, marginTop: spacing.lg },
  roleBannerText: { fontFamily: type.bodyMedium, fontSize: fontSize.sm, color: colors.moss },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md },
  logout: { marginTop: spacing.xxl, alignItems: 'center', paddingVertical: spacing.md },
  logoutText: { fontFamily: type.bodyMedium, color: colors.rust, fontSize: fontSize.sm },
});
