import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { LedgerRow } from '@/components/LedgerRow';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import { useAuth } from '@/context/AuthContext';
import * as api from '@/services/api';

export const MyClassesScreen: React.FC = () => {
  const { user } = useAuth();
  const teacher = api.getTeacherById(user!.id)!;
  const classesTeaching = api.getClassesTeacherTeachesIn(teacher.id);

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="Teacher" title="My Classes" />
      {classesTeaching.map((cls) => {
        const subjectsHere = api.getSubjectsForTeacherInClass(teacher.id, cls.id);
        const students = api.getStudentsByClass(cls.id);
        const isClassTeacher = cls.classTeacherId === teacher.id;
        return (
          <View key={cls.id} style={styles.card}>
            <View style={styles.cardHeader}>
              <Text style={styles.className}>{cls.name}</Text>
              {isClassTeacher && (
                <View style={styles.tag}>
                  <Text style={styles.tagText}>CLASS TEACHER</Text>
                </View>
              )}
            </View>
            <Text style={styles.subtitle}>Teaching: {subjectsHere.map((s) => s.name).join(', ')}</Text>
            <Text style={styles.rosterLabel}>ROSTER · {students.length} STUDENTS</Text>
            {students.map((s, i) => (
              <LedgerRow
                key={s.id}
                index={s.rollNo}
                title={s.name}
                subtitle={`Roll No. ${s.rollNo}`}
                style={i === students.length - 1 ? { borderBottomWidth: 0 } : undefined}
              />
            ))}
          </View>
        );
      })}
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.rule,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  className: { fontFamily: type.display, fontSize: fontSize.lg, color: colors.ink },
  tag: { backgroundColor: colors.goldSoft, paddingHorizontal: spacing.sm, paddingVertical: 3, borderRadius: radius.pill },
  tagText: { fontFamily: type.mono, fontSize: 9, color: '#8A6A24', letterSpacing: 0.5 },
  subtitle: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, marginTop: 4 },
  rosterLabel: { fontFamily: type.mono, fontSize: 10, color: colors.gold, letterSpacing: 0.5, marginTop: spacing.md, marginBottom: spacing.xs },
});
