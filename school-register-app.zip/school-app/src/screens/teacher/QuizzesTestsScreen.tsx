import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { Button } from '@/components/Button';
import { LedgerRow } from '@/components/LedgerRow';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import { useAuth } from '@/context/AuthContext';
import * as api from '@/services/api';
import { AssessmentType } from '@/types';

const TYPES: AssessmentType[] = ['quiz', 'test', 'midterm', 'final'];

export const QuizzesTestsScreen: React.FC = () => {
  const { user } = useAuth();
  const teacher = api.getTeacherById(user!.id)!;
  const classesTeaching = api.getClassesTeacherTeachesIn(teacher.id);

  const [classId, setClassId] = useState(classesTeaching[0]?.id);
  const subjectsForClass = classId ? api.getSubjectsForTeacherInClass(teacher.id, classId) : [];
  const [subjectId, setSubjectId] = useState(subjectsForClass[0]?.id);
  const [type, setType] = useState<AssessmentType>('quiz');
  const [title, setTitle] = useState('');
  const [maxMarks, setMaxMarks] = useState('20');
  const [, forceRerender] = useState(0);

  const created = classId
    ? api.getAssessmentsForClass(classId).filter((a) => a.createdBy === teacher.id)
    : [];

  const handleCreate = () => {
    if (!classId || !subjectId || !title.trim()) return;
    api.createAssessment({
      classId,
      subjectId,
      title: title.trim(),
      type,
      date: new Date().toISOString().slice(0, 10),
      maxMarks: Number(maxMarks) || 20,
      createdBy: teacher.id,
    });
    setTitle('');
    forceRerender((n) => n + 1);
  };

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="Teacher" title="Quizzes & Tests" />

      <Text style={styles.label}>Class</Text>
      <View style={styles.chipRow}>
        {classesTeaching.map((c) => (
          <TouchableOpacity
            key={c.id}
            style={[styles.chip, c.id === classId && styles.chipActive]}
            onPress={() => {
              setClassId(c.id);
              const subs = api.getSubjectsForTeacherInClass(teacher.id, c.id);
              setSubjectId(subs[0]?.id);
            }}
          >
            <Text style={[styles.chipText, c.id === classId && styles.chipTextActive]}>{c.name}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Subject</Text>
      <View style={styles.chipRow}>
        {subjectsForClass.map((s) => (
          <TouchableOpacity
            key={s.id}
            style={[styles.chip, s.id === subjectId && styles.chipActive]}
            onPress={() => setSubjectId(s.id)}
          >
            <Text style={[styles.chipText, s.id === subjectId && styles.chipTextActive]}>{s.name}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Type</Text>
      <View style={styles.chipRow}>
        {TYPES.map((t) => (
          <TouchableOpacity key={t} style={[styles.chip, t === type && styles.chipActive]} onPress={() => setType(t)}>
            <Text style={[styles.chipText, t === type && styles.chipTextActive]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Title</Text>
      <TextInput
        style={styles.input}
        value={title}
        onChangeText={setTitle}
        placeholder="e.g. Fractions Quiz 2"
        placeholderTextColor={colors.slateMuted}
      />

      <Text style={styles.label}>Max marks</Text>
      <TextInput
        style={styles.input}
        value={maxMarks}
        onChangeText={setMaxMarks}
        keyboardType="number-pad"
      />

      <Button label="Create Assessment" onPress={handleCreate} style={{ marginTop: spacing.md }} />

      <SectionHeader eyebrow="This class" title="Your assessments" />
      <View style={styles.card}>
        {created.map((a, i) => (
          <LedgerRow
            key={a.id}
            index={i + 1}
            title={a.title}
            subtitle={`${a.type.toUpperCase()} · ${api.getSubjectById(a.subjectId)?.name} · Max ${a.maxMarks}`}
            style={i === created.length - 1 ? { borderBottomWidth: 0 } : undefined}
          />
        ))}
        {created.length === 0 && <Text style={styles.empty}>No assessments created for this class yet.</Text>}
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  label: { fontFamily: type.mono, fontSize: 11, color: colors.slateMuted, letterSpacing: 0.5, marginTop: spacing.md, marginBottom: spacing.xs, textTransform: 'uppercase' },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  chip: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.pill, backgroundColor: colors.sage },
  chipActive: { backgroundColor: colors.ink },
  chipText: { fontFamily: type.bodyMedium, fontSize: fontSize.xs, color: colors.slate, textTransform: 'capitalize' },
  chipTextActive: { color: colors.paper },
  input: {
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.rule,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    fontFamily: type.body,
    fontSize: fontSize.md,
    color: colors.slate,
  },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md },
  empty: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, paddingVertical: spacing.lg, textAlign: 'center' },
});
