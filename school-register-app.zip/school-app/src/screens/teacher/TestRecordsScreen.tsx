import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { Button } from '@/components/Button';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import { useAuth } from '@/context/AuthContext';
import * as api from '@/services/api';

export const TestRecordsScreen: React.FC = () => {
  const { user } = useAuth();
  const teacher = api.getTeacherById(user!.id)!;
  const classesTeaching = api.getClassesTeacherTeachesIn(teacher.id);
  const [classId, setClassId] = useState(classesTeaching[0]?.id);
  const assessments = classId ? api.getAssessmentsForClass(classId) : [];
  const [assessmentId, setAssessmentId] = useState(assessments[0]?.id);
  const [, forceRerender] = useState(0);

  const assessment = assessments.find((a) => a.id === assessmentId);
  const students = classId ? api.getStudentsByClass(classId) : [];

  const [marks, setMarks] = useState<Record<string, string>>({});

  const getInitial = (studentId: string) => {
    if (marks[studentId] !== undefined) return marks[studentId];
    const existing = assessmentId ? api.getResultForStudent(assessmentId, studentId) : undefined;
    return existing ? String(existing.marksObtained) : '';
  };

  const saveMarks = () => {
    if (!assessmentId) return;
    students.forEach((s) => {
      const val = marks[s.id];
      if (val !== undefined && val !== '' && !Number.isNaN(Number(val))) {
        api.recordResult({ assessmentId, studentId: s.id, marksObtained: Number(val) });
      }
    });
    forceRerender((n) => n + 1);
  };

  const classAverage = () => {
    if (!assessmentId) return null;
    const results = api.getResultsForAssessment(assessmentId);
    if (results.length === 0) return null;
    return (results.reduce((sum, r) => sum + r.marksObtained, 0) / results.length).toFixed(1);
  };

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="Teacher" title="Test Records" />

      <Text style={styles.label}>Class</Text>
      <View style={styles.chipRow}>
        {classesTeaching.map((c) => (
          <TouchableOpacity
            key={c.id}
            style={[styles.chip, c.id === classId && styles.chipActive]}
            onPress={() => {
              setClassId(c.id);
              const next = api.getAssessmentsForClass(c.id);
              setAssessmentId(next[0]?.id);
              setMarks({});
            }}
          >
            <Text style={[styles.chipText, c.id === classId && styles.chipTextActive]}>{c.name}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Assessment</Text>
      <View style={styles.chipRow}>
        {assessments.map((a) => (
          <TouchableOpacity
            key={a.id}
            style={[styles.chip, a.id === assessmentId && styles.chipActive]}
            onPress={() => {
              setAssessmentId(a.id);
              setMarks({});
            }}
          >
            <Text style={[styles.chipText, a.id === assessmentId && styles.chipTextActive]}>{a.title}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {assessment && (
        <>
          <View style={styles.card}>
            {students.map((s, i) => (
              <View key={s.id} style={[styles.row, i === students.length - 1 && { borderBottomWidth: 0 }]}>
                <Text style={styles.name}>{s.name}</Text>
                <View style={styles.markInputWrap}>
                  <TextInput
                    style={styles.markInput}
                    keyboardType="number-pad"
                    value={getInitial(s.id)}
                    onChangeText={(val) => setMarks((prev) => ({ ...prev, [s.id]: val }))}
                    placeholder="—"
                    placeholderTextColor={colors.slateMuted}
                  />
                  <Text style={styles.maxMarks}> / {assessment.maxMarks}</Text>
                </View>
              </View>
            ))}
          </View>

          <Button label="Save Marks" onPress={saveMarks} style={{ marginTop: spacing.md }} />

          {classAverage() && (
            <Text style={styles.average}>Class average: {classAverage()} / {assessment.maxMarks}</Text>
          )}
        </>
      )}
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  label: { fontFamily: type.mono, fontSize: 11, color: colors.slateMuted, letterSpacing: 0.5, marginTop: spacing.md, marginBottom: spacing.xs, textTransform: 'uppercase' },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  chip: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.pill, backgroundColor: colors.sage },
  chipActive: { backgroundColor: colors.ink },
  chipText: { fontFamily: type.bodyMedium, fontSize: fontSize.xs, color: colors.slate },
  chipTextActive: { color: colors.paper },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md, marginTop: spacing.md },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.rule },
  name: { fontFamily: type.bodyMedium, fontSize: fontSize.md, color: colors.slate },
  markInputWrap: { flexDirection: 'row', alignItems: 'center' },
  markInput: {
    fontFamily: type.mono,
    fontSize: fontSize.md,
    color: colors.ink,
    borderBottomWidth: 1,
    borderBottomColor: colors.gold,
    minWidth: 32,
    textAlign: 'right',
    paddingVertical: 2,
  },
  maxMarks: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted },
  average: { fontFamily: type.bodyMedium, fontSize: fontSize.sm, color: colors.moss, marginTop: spacing.md, textAlign: 'center' },
});
