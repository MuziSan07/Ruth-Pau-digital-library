import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { Button } from '@/components/Button';
import { Badge } from '@/components/Badge';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import { useAuth } from '@/context/AuthContext';
import * as api from '@/services/api';
import { Role } from '@/types';

export const FeedbackScreen: React.FC = () => {
  const { user } = useAuth();
  const [, forceRerender] = useState(0);
  const [toRole, setToRole] = useState<Role>('admin');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const received = api.getFeedbackForRole('teacher').filter((f) => f.fromId !== user!.id);
  const sent = api.getFeedbackFrom(user!.id);

  const send = () => {
    if (!subject.trim() || !message.trim()) return;
    api.submitFeedback({ fromId: user!.id, fromRole: 'teacher', fromName: user!.name, toRole, subject: subject.trim(), message: message.trim() });
    setSubject('');
    setMessage('');
    forceRerender((n) => n + 1);
  };

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="Teacher" title="Feedback" />

      <Text style={styles.label}>Send to</Text>
      <View style={styles.chipRow}>
        {(['admin', 'parent'] as Role[]).map((r) => (
          <TouchableOpacity key={r} style={[styles.chip, r === toRole && styles.chipActive]} onPress={() => setToRole(r)}>
            <Text style={[styles.chipText, r === toRole && styles.chipTextActive]}>{r === 'admin' ? 'Admin' : 'Parents'}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TextInput style={styles.input} placeholder="Subject" placeholderTextColor={colors.slateMuted} value={subject} onChangeText={setSubject} />
      <TextInput
        style={[styles.input, styles.textArea]}
        placeholder="Write your message..."
        placeholderTextColor={colors.slateMuted}
        value={message}
        onChangeText={setMessage}
        multiline
      />
      <Button label="Send Feedback" onPress={send} style={{ marginTop: spacing.sm }} />

      <SectionHeader eyebrow="Inbox" title="Received" />
      <View style={styles.card}>
        {received.map((f, i) => (
          <View key={f.id} style={[styles.entry, i === received.length - 1 && { borderBottomWidth: 0 }]}>
            <View style={styles.entryHeader}>
              <Text style={styles.entrySubject}>{f.subject}</Text>
              <Badge label={f.status} />
            </View>
            <Text style={styles.entryMeta}>{f.fromName} · {f.date}</Text>
            <Text style={styles.entryMessage}>{f.message}</Text>
          </View>
        ))}
        {received.length === 0 && <Text style={styles.empty}>No messages yet.</Text>}
      </View>

      <SectionHeader eyebrow="Outbox" title="Sent" />
      <View style={styles.card}>
        {sent.map((f, i) => (
          <View key={f.id} style={[styles.entry, i === sent.length - 1 && { borderBottomWidth: 0 }]}>
            <View style={styles.entryHeader}>
              <Text style={styles.entrySubject}>{f.subject}</Text>
              <Badge label={f.status} />
            </View>
            <Text style={styles.entryMeta}>To {f.toRole} · {f.date}</Text>
          </View>
        ))}
        {sent.length === 0 && <Text style={styles.empty}>You haven't sent any feedback yet.</Text>}
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  label: { fontFamily: type.mono, fontSize: 11, color: colors.slateMuted, letterSpacing: 0.5, marginTop: spacing.md, marginBottom: spacing.xs, textTransform: 'uppercase' },
  chipRow: { flexDirection: 'row', gap: spacing.xs, marginBottom: spacing.sm },
  chip: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.pill, backgroundColor: colors.sage },
  chipActive: { backgroundColor: colors.ink },
  chipText: { fontFamily: type.bodyMedium, fontSize: fontSize.xs, color: colors.slate },
  chipTextActive: { color: colors.paper },
  input: { backgroundColor: colors.white, borderWidth: 1, borderColor: colors.rule, borderRadius: radius.md, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, fontFamily: type.body, fontSize: fontSize.md, color: colors.slate, marginBottom: spacing.sm },
  textArea: { minHeight: 80, textAlignVertical: 'top' },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md },
  entry: { paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.rule },
  entryHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  entrySubject: { fontFamily: type.bodyMedium, fontSize: fontSize.md, color: colors.slate },
  entryMeta: { fontFamily: type.mono, fontSize: 11, color: colors.slateMuted, marginTop: 2 },
  entryMessage: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slate, marginTop: 4, lineHeight: 19 },
  empty: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, paddingVertical: spacing.lg, textAlign: 'center' },
});
