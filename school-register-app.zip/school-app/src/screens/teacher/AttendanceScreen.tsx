import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { Badge } from '@/components/Badge';
import { Button } from '@/components/Button';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import { useAuth } from '@/context/AuthContext';
import * as api from '@/services/api';
import { AttendanceStatus } from '@/types';

const CYCLE: AttendanceStatus[] = ['present', 'absent', 'late', 'excused'];
const todayISO = () => new Date().toISOString().slice(0, 10);

export const AttendanceScreen: React.FC = () => {
  const { user } = useAuth();
  const teacher = api.getTeacherById(user!.id)!;
  const classesTeaching = api.getClassesTeacherTeachesIn(teacher.id);
  const [selectedClassId, setSelectedClassId] = useState(classesTeaching[0]?.id);
  const students = selectedClassId ? api.getStudentsByClass(selectedClassId) : [];

  const [draft, setDraft] = useState<Record<string, AttendanceStatus>>(() =>
    Object.fromEntries(students.map((s) => [s.id, 'present' as AttendanceStatus]))
  );
  const [submitted, setSubmitted] = useState(false);

  const selectClass = (id: string) => {
    setSelectedClassId(id);
    const nextStudents = api.getStudentsByClass(id);
    setDraft(Object.fromEntries(nextStudents.map((s) => [s.id, 'present' as AttendanceStatus])));
    setSubmitted(false);
  };

  const cycleStatus = (studentId: string) => {
    setDraft((prev) => {
      const current = prev[studentId] ?? 'present';
      const nextIndex = (CYCLE.indexOf(current) + 1) % CYCLE.length;
      return { ...prev, [studentId]: CYCLE[nextIndex] };
    });
  };

  const submit = () => {
    if (!selectedClassId) return;
    api.submitAttendance(selectedClassId, todayISO(), teacher.id, draft);
    setSubmitted(true);
  };

  const history = selectedClassId ? api.getAttendanceForClass(selectedClassId) : [];

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="Teacher · Today" title="Take Attendance" />

      <View style={styles.classPicker}>
        {classesTeaching.map((c) => (
          <TouchableOpacity
            key={c.id}
            style={[styles.classChip, c.id === selectedClassId && styles.classChipActive]}
            onPress={() => selectClass(c.id)}
          >
            <Text style={[styles.classChipText, c.id === selectedClassId && styles.classChipTextActive]}>{c.name}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.hint}>Tap a student's status to cycle: Present → Absent → Late → Excused.</Text>

      <View style={styles.card}>
        {students.map((s, i) => {
          const status = draft[s.id] ?? 'present';
          return (
            <TouchableOpacity
              key={s.id}
              style={[styles.row, i === students.length - 1 && { borderBottomWidth: 0 }]}
              onPress={() => cycleStatus(s.id)}
              activeOpacity={0.6}
            >
              <Text style={styles.rollNo}>{String(s.rollNo).padStart(2, '0')}</Text>
              <Text style={styles.name}>{s.name}</Text>
              <Badge label={status} />
            </TouchableOpacity>
          );
        })}
      </View>

      <Button label={submitted ? 'Attendance Submitted ✓' : `Submit for ${todayISO()}`} onPress={submit} style={{ marginTop: spacing.lg }} />

      <SectionHeader eyebrow="History" title="Recent records" />
      <View style={styles.card}>
        {history.slice(0, 5).map((h, i) => {
          const presentCount = Object.values(h.entries).filter((v) => v === 'present').length;
          return (
            <View key={h.id} style={[styles.historyRow, i === Math.min(history.length, 5) - 1 && { borderBottomWidth: 0 }]}>
              <Text style={styles.historyDate}>{h.date}</Text>
              <Text style={styles.historyMeta}>
                {presentCount}/{Object.keys(h.entries).length} present
              </Text>
            </View>
          );
        })}
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  classPicker: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs, marginBottom: spacing.sm },
  classChip: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.pill, backgroundColor: colors.sage },
  classChipActive: { backgroundColor: colors.ink },
  classChipText: { fontFamily: type.bodyMedium, fontSize: fontSize.xs, color: colors.slate },
  classChipTextActive: { color: colors.paper },
  hint: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, marginBottom: spacing.md },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.rule, gap: spacing.sm },
  rollNo: { fontFamily: type.mono, fontSize: fontSize.sm, color: colors.gold, width: 24 },
  name: { fontFamily: type.bodyMedium, fontSize: fontSize.md, color: colors.slate, flex: 1 },
  historyRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.rule },
  historyDate: { fontFamily: type.mono, fontSize: fontSize.sm, color: colors.slate },
  historyMeta: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted },
});
