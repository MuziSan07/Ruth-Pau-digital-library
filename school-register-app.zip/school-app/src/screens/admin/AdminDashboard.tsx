import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { StatCard } from '@/components/StatCard';
import { LedgerRow } from '@/components/LedgerRow';
import { colors, type, fontSize, spacing, radius } from '@/theme/tokens';
import { useAuth } from '@/context/AuthContext';
import * as api from '@/services/api';
import { useNavigation } from '@react-navigation/native';

export const AdminDashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const navigation = useNavigation<any>();

  const teachers = api.getTeachers();
  const students = api.getStudents();
  const feeRecords = api.getFeeRecords();
  const outstandingFees = feeRecords.filter((f) => f.status !== 'paid').length;
  const openFeedback = api.getAllFeedback().filter((f) => f.status === 'open').length;
  const pendingSalaries = api.getSalaryRecords().filter((s) => s.status === 'pending').length;

  const links = [
    { label: 'Manage Teachers & Assignments', screen: 'ManageTeachers' },
    { label: 'Fee Management', screen: 'FeeManagement' },
    { label: 'Salary Management', screen: 'SalaryManagement' },
    { label: 'Academic Calendar', screen: 'AcademicCalendar' },
    { label: 'Feedback Inbox', screen: 'FeedbackMonitor' },
  ];

  return (
    <ScreenContainer>
      <View style={styles.header}>
        <Text style={styles.eyebrow}>ADMIN PANEL</Text>
        <Text style={styles.title}>Good morning, {user?.name.split(' ')[0]}</Text>
      </View>

      <View style={styles.statsRow}>
        <StatCard label="Teachers" value={String(teachers.length)} />
        <StatCard label="Students" value={String(students.length)} />
        <StatCard label="Fees Due" value={String(outstandingFees)} accent={outstandingFees > 0 ? colors.rust : colors.moss} />
      </View>

      <SectionHeader eyebrow="Needs attention" title="Open items" />
      <View style={styles.card}>
        <LedgerRow index="01" title="Unread feedback" subtitle={`${openFeedback} messages waiting for review`} onPress={() => navigation.navigate('FeedbackMonitor')} />
        <LedgerRow index="02" title="Pending salary payouts" subtitle={`${pendingSalaries} teachers awaiting payment`} onPress={() => navigation.navigate('SalaryManagement')} />
        <LedgerRow index="03" title="Outstanding fee balances" subtitle={`${outstandingFees} students with dues or overdue fees`} onPress={() => navigation.navigate('FeeManagement')} style={{ borderBottomWidth: 0 }} />
      </View>

      <SectionHeader eyebrow="Manage" title="School operations" />
      <View style={styles.card}>
        {links.map((l, i) => (
          <LedgerRow
            key={l.screen}
            index={i + 1}
            title={l.label}
            onPress={() => navigation.navigate(l.screen)}
            style={i === links.length - 1 ? { borderBottomWidth: 0 } : undefined}
          />
        ))}
      </View>

      <TouchableOpacity style={styles.logout} onPress={logout}>
        <Text style={styles.logoutText}>Sign out</Text>
      </TouchableOpacity>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  header: { marginTop: spacing.lg, marginBottom: spacing.md },
  eyebrow: { fontFamily: type.mono, fontSize: 11, letterSpacing: 1.5, color: colors.gold },
  title: { fontFamily: type.display, fontSize: fontSize.xxl, color: colors.ink, marginTop: 4 },
  statsRow: { flexDirection: 'row', marginTop: spacing.sm },
  card: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.rule,
    paddingHorizontal: spacing.md,
  },
  logout: { marginTop: spacing.xxl, alignItems: 'center', paddingVertical: spacing.md },
  logoutText: { fontFamily: type.bodyMedium, color: colors.rust, fontSize: fontSize.sm },
});
