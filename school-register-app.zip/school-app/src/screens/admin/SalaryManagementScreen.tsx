import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { LedgerRow } from '@/components/LedgerRow';
import { Badge } from '@/components/Badge';
import { StatCard } from '@/components/StatCard';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import * as api from '@/services/api';

export const SalaryManagementScreen: React.FC = () => {
  const [, forceRerender] = useState(0);
  const refresh = () => forceRerender((n) => n + 1);

  const records = api.getSalaryRecords();
  const totalPayroll = records.reduce((sum, r) => sum + r.amount, 0);
  const pending = records.filter((r) => r.status === 'pending');

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="Admin · Finance" title="Salary Management" />
      <View style={styles.statsRow}>
        <StatCard label="Monthly payroll" value={`Rs ${totalPayroll.toLocaleString()}`} />
        <StatCard label="Pending payouts" value={String(pending.length)} accent={pending.length > 0 ? colors.gold : colors.moss} />
      </View>

      <SectionHeader title="Teacher salaries — August 2026" />
      <View style={styles.card}>
        {records.map((r, i) => {
          const teacher = api.getTeacherById(r.teacherId);
          return (
            <LedgerRow
              key={r.id}
              index={i + 1}
              title={teacher?.name ?? 'Unknown teacher'}
              subtitle={`Rs ${r.amount.toLocaleString()} · ${r.month}`}
              right={
                <View style={{ alignItems: 'flex-end', gap: 6 }}>
                  <Badge label={r.status} />
                  {r.status === 'pending' && (
                    <TouchableOpacity
                      onPress={() => {
                        api.markSalaryPaid(r.id);
                        refresh();
                      }}
                    >
                      <Text style={styles.markPaid}>Release payment</Text>
                    </TouchableOpacity>
                  )}
                </View>
              }
              style={i === records.length - 1 ? { borderBottomWidth: 0 } : undefined}
            />
          );
        })}
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  statsRow: { flexDirection: 'row', marginTop: spacing.sm },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md },
  markPaid: { fontFamily: type.bodyMedium, fontSize: 11, color: colors.moss },
});
