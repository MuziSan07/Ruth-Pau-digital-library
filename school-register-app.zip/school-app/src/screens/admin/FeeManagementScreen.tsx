import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { LedgerRow } from '@/components/LedgerRow';
import { Badge } from '@/components/Badge';
import { StatCard } from '@/components/StatCard';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import * as api from '@/services/api';

export const FeeManagementScreen: React.FC = () => {
  const [, forceRerender] = useState(0);
  const refresh = () => forceRerender((n) => n + 1);

  const records = api.getFeeRecords();
  const totalOutstanding = records.filter((r) => r.status !== 'paid').reduce((sum, r) => sum + r.amount, 0);
  const overdueCount = records.filter((r) => r.status === 'overdue').length;

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="Admin · Finance" title="Fee Management" />
      <View style={styles.statsRow}>
        <StatCard label="Outstanding" value={`Rs ${totalOutstanding.toLocaleString()}`} accent={colors.rust} />
        <StatCard label="Overdue accounts" value={String(overdueCount)} accent={colors.rust} />
      </View>

      <SectionHeader title="Student fee records" />
      <View style={styles.card}>
        {records.map((r, i) => {
          const student = api.getStudentById(r.studentId);
          return (
            <LedgerRow
              key={r.id}
              index={i + 1}
              title={student?.name ?? 'Unknown student'}
              subtitle={`${r.term} · Rs ${r.amount.toLocaleString()} · Due ${r.dueDate}`}
              right={
                <View style={{ alignItems: 'flex-end', gap: 6 }}>
                  <Badge label={r.status} />
                  {r.status !== 'paid' && (
                    <TouchableOpacity
                      onPress={() => {
                        api.markFeePaid(r.id);
                        refresh();
                      }}
                    >
                      <Text style={styles.markPaid}>Mark paid</Text>
                    </TouchableOpacity>
                  )}
                </View>
              }
              style={i === records.length - 1 ? { borderBottomWidth: 0 } : undefined}
            />
          );
        })}
        {records.filter((r) => r.status !== 'paid').length === 0 && (
          <Text style={styles.empty}>All fee accounts are settled.</Text>
        )}
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  statsRow: { flexDirection: 'row', marginTop: spacing.sm },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md },
  markPaid: { fontFamily: type.bodyMedium, fontSize: 11, color: colors.moss },
  empty: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, paddingVertical: spacing.lg, textAlign: 'center' },
});
