import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { LedgerRow } from '@/components/LedgerRow';
import { Badge } from '@/components/Badge';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import * as api from '@/services/api';

export const ManageTeachersScreen: React.FC = () => {
  const [, forceRerender] = useState(0);
  const [expandedClass, setExpandedClass] = useState<string | null>(null);
  const classes = api.getClasses();
  const teachers = api.getTeachers();

  const refresh = () => forceRerender((n) => n + 1);

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="Admin · Staffing" title="Classes & Teachers" />
      <Text style={styles.hint}>
        Every class has exactly one class teacher. Different teachers can still teach different subjects within that class.
      </Text>

      {classes.map((cls) => {
        const classTeacher = api.getTeacherById(cls.classTeacherId);
        const isExpanded = expandedClass === cls.id;
        return (
          <View key={cls.id} style={styles.classCard}>
            <TouchableOpacity onPress={() => setExpandedClass(isExpanded ? null : cls.id)}>
              <LedgerRow
                title={cls.name}
                subtitle={`Class Teacher: ${classTeacher?.name ?? 'Unassigned'}`}
                right={<Text style={styles.chevron}>{isExpanded ? '−' : '+'}</Text>}
                style={{ borderBottomWidth: isExpanded ? 1 : 0 }}
              />
            </TouchableOpacity>

            {isExpanded && (
              <View style={styles.expanded}>
                <Text style={styles.subLabel}>Reassign class teacher</Text>
                <View style={styles.chipRow}>
                  {teachers.map((t) => (
                    <TouchableOpacity
                      key={t.id}
                      style={[styles.chip, t.id === cls.classTeacherId && styles.chipActive]}
                      onPress={() => {
                        api.assignClassTeacher(cls.id, t.id);
                        refresh();
                      }}
                    >
                      <Text style={[styles.chipText, t.id === cls.classTeacherId && styles.chipTextActive]}>
                        {t.name.split(' ')[0]}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>

                <Text style={[styles.subLabel, { marginTop: spacing.md }]}>Subject teachers</Text>
                {api.getSubjects().map((subj) => {
                  const assignedId = cls.subjectTeacherIds[subj.id];
                  const assigned = assignedId ? api.getTeacherById(assignedId) : undefined;
                  return (
                    <View key={subj.id} style={styles.subjectRow}>
                      <Text style={styles.subjectName}>{subj.name}</Text>
                      <View style={styles.chipRowInline}>
                        {teachers
                          .filter((t) => t.subjectsTaught.includes(subj.id))
                          .map((t) => (
                            <TouchableOpacity
                              key={t.id}
                              style={[styles.miniChip, t.id === assignedId && styles.miniChipActive]}
                              onPress={() => {
                                api.assignSubjectTeacher(cls.id, subj.id, t.id);
                                refresh();
                              }}
                            >
                              <Text style={[styles.miniChipText, t.id === assignedId && styles.miniChipTextActive]}>
                                {t.name.split(' ')[0]}
                              </Text>
                            </TouchableOpacity>
                          ))}
                      </View>
                    </View>
                  );
                })}
              </View>
            )}
          </View>
        );
      })}

      <SectionHeader eyebrow="Directory" title="All teachers" />
      <View style={styles.card}>
        {teachers.map((t, i) => (
          <LedgerRow
            key={t.id}
            index={i + 1}
            title={t.name}
            subtitle={`${t.subjectsTaught.map((s) => api.getSubjectById(s)?.name).join(', ')}${
              t.isClassTeacherOf ? ` · Class Teacher of ${api.getClassById(t.isClassTeacherOf)?.name}` : ''
            }`}
            right={<Badge label={t.salaryStatus} />}
            style={i === teachers.length - 1 ? { borderBottomWidth: 0 } : undefined}
          />
        ))}
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  hint: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, marginBottom: spacing.md, lineHeight: 20 },
  classCard: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.rule,
    marginBottom: spacing.md,
    paddingHorizontal: spacing.md,
  },
  chevron: { fontFamily: type.mono, fontSize: fontSize.lg, color: colors.gold },
  expanded: { paddingBottom: spacing.md },
  subLabel: { fontFamily: type.bodyMedium, fontSize: fontSize.xs, color: colors.slateMuted, marginTop: spacing.sm, marginBottom: spacing.xs, textTransform: 'uppercase', letterSpacing: 0.5 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  chipRowInline: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs, flex: 1, justifyContent: 'flex-end' },
  chip: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.pill, backgroundColor: colors.sage },
  chipActive: { backgroundColor: colors.ink },
  chipText: { fontFamily: type.bodyMedium, fontSize: fontSize.xs, color: colors.slate },
  chipTextActive: { color: colors.paper },
  subjectRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: spacing.xs },
  subjectName: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slate, width: 90 },
  miniChip: { paddingHorizontal: spacing.sm, paddingVertical: 4, borderRadius: radius.pill, borderWidth: 1, borderColor: colors.rule },
  miniChipActive: { backgroundColor: colors.goldSoft, borderColor: colors.gold },
  miniChipText: { fontFamily: type.body, fontSize: 11, color: colors.slateMuted },
  miniChipTextActive: { color: '#8A6A24', fontFamily: type.bodyMedium },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md },
});
