import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { LedgerRow } from '@/components/LedgerRow';
import { Badge } from '@/components/Badge';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import * as api from '@/services/api';

export const FeedbackMonitorScreen: React.FC = () => {
  const [, forceRerender] = useState(0);
  const refresh = () => forceRerender((n) => n + 1);
  const entries = api.getAllFeedback();

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="Admin · Communication" title="Feedback Inbox" />
      <Text style={styles.hint}>Every message between teachers, parents, and admin passes through here for oversight.</Text>

      <View style={styles.card}>
        {entries.map((f, i) => (
          <View key={f.id} style={[styles.entry, i === entries.length - 1 && { borderBottomWidth: 0 }]}>
            <LedgerRow
              index={i + 1}
              title={f.subject}
              subtitle={`${f.fromName} (${f.fromRole}) → ${f.toRole} · ${f.date}`}
              right={<Badge label={f.status} />}
              style={{ borderBottomWidth: 0, paddingBottom: 4 }}
            />
            <Text style={styles.message}>{f.message}</Text>
            {f.status === 'open' && (
              <TouchableOpacity
                onPress={() => {
                  api.markFeedbackReviewed(f.id);
                  refresh();
                }}
                style={styles.reviewBtn}
              >
                <Text style={styles.reviewText}>Mark as reviewed</Text>
              </TouchableOpacity>
            )}
          </View>
        ))}
        {entries.length === 0 && <Text style={styles.empty}>No feedback yet.</Text>}
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  hint: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, marginBottom: spacing.md, lineHeight: 20 },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md },
  entry: { paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.rule },
  message: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slate, lineHeight: 19, marginTop: 2, marginBottom: spacing.xs },
  reviewBtn: { alignSelf: 'flex-start' },
  reviewText: { fontFamily: type.bodyMedium, fontSize: 12, color: colors.moss },
  empty: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, paddingVertical: spacing.lg, textAlign: 'center' },
});
