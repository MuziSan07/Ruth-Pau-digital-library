import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { ScreenContainer } from '@/components/ScreenContainer';
import { SectionHeader } from '@/components/SectionHeader';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';
import * as api from '@/services/api';
import { useAuth } from '@/context/AuthContext';

const categoryColor: Record<string, string> = {
  exam: colors.rust,
  holiday: colors.moss,
  event: colors.gold,
  meeting: colors.ink,
  deadline: colors.rust,
};

export const AcademicCalendarScreen: React.FC = () => {
  const { user } = useAuth();
  const events = api.getCalendarEvents(user?.role);

  return (
    <ScreenContainer>
      <SectionHeader eyebrow="School-wide" title="Academic Calendar" />
      <View style={styles.card}>
        {events.map((e, i) => (
          <View key={e.id} style={[styles.row, i === events.length - 1 && { borderBottomWidth: 0 }]}>
            <View style={[styles.dot, { backgroundColor: categoryColor[e.category] }]} />
            <View style={styles.dateBlock}>
              <Text style={styles.date}>{e.date.slice(8, 10)}</Text>
              <Text style={styles.month}>{new Date(e.date).toLocaleString('en', { month: 'short' }).toUpperCase()}</Text>
            </View>
            <View style={styles.body}>
              <Text style={styles.title}>{e.title}</Text>
              <Text style={styles.category}>{e.category.toUpperCase()}</Text>
              {e.description ? <Text style={styles.desc}>{e.description}</Text> : null}
            </View>
          </View>
        ))}
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  card: { backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.rule, paddingHorizontal: spacing.md },
  row: { flexDirection: 'row', alignItems: 'flex-start', paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.rule, gap: spacing.sm },
  dot: { width: 8, height: 8, borderRadius: 4, marginTop: 8 },
  dateBlock: { alignItems: 'center', width: 42 },
  date: { fontFamily: type.display, fontSize: fontSize.lg, color: colors.ink },
  month: { fontFamily: type.mono, fontSize: 10, color: colors.slateMuted, letterSpacing: 0.5 },
  body: { flex: 1 },
  title: { fontFamily: type.bodyMedium, fontSize: fontSize.md, color: colors.slate },
  category: { fontFamily: type.mono, fontSize: 10, color: colors.gold, marginTop: 2, letterSpacing: 0.5 },
  desc: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, marginTop: 4 },
});
