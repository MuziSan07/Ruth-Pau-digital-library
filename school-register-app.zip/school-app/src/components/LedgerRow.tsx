import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { colors, type, fontSize, spacing } from '@/theme/tokens';

interface LedgerRowProps {
  index?: number | string;
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
}

/**
 * A row styled like an entry in a school ledger: a small brass-gold index
 * tab on the left, a hairline rule beneath — used everywhere a list of
 * students, records, or events needs to feel like a register, not a card.
 */
export const LedgerRow: React.FC<LedgerRowProps> = ({ index, title, subtitle, right, onPress, style }) => {
  const Wrapper = onPress ? TouchableOpacity : View;
  return (
    <Wrapper style={[styles.row, style]} onPress={onPress} activeOpacity={0.6}>
      {index !== undefined && (
        <Text style={styles.index}>{typeof index === 'number' ? String(index).padStart(2, '0') : index}</Text>
      )}
      <View style={styles.body}>
        <Text style={styles.title}>{title}</Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
      </View>
      {right ? <View style={styles.right}>{right}</View> : null}
    </Wrapper>
  );
};

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.rule,
  },
  index: {
    fontFamily: type.mono,
    fontSize: fontSize.sm,
    color: colors.gold,
    width: 28,
  },
  body: { flex: 1, paddingRight: spacing.sm },
  title: { fontFamily: type.bodyMedium, fontSize: fontSize.md, color: colors.slate },
  subtitle: { fontFamily: type.body, fontSize: fontSize.sm, color: colors.slateMuted, marginTop: 2 },
  right: { alignItems: 'flex-end' },
});
