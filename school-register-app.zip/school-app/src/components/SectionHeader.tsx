import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, type, fontSize, spacing } from '@/theme/tokens';

export const SectionHeader: React.FC<{ eyebrow?: string; title: string; action?: React.ReactNode }> = ({
  eyebrow,
  title,
  action,
}) => (
  <View style={styles.wrap}>
    <View>
      {eyebrow ? <Text style={styles.eyebrow}>{eyebrow}</Text> : null}
      <Text style={styles.title}>{title}</Text>
    </View>
    {action}
  </View>
);

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginTop: spacing.xl,
    marginBottom: spacing.sm,
  },
  eyebrow: {
    fontFamily: type.mono,
    fontSize: 11,
    letterSpacing: 1,
    color: colors.gold,
    textTransform: 'uppercase',
    marginBottom: 2,
  },
  title: {
    fontFamily: type.display,
    fontSize: fontSize.xl,
    color: colors.ink,
  },
});
