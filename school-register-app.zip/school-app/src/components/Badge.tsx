import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';

type Tone = 'moss' | 'rust' | 'gold' | 'neutral';

const toneStyles: Record<Tone, { bg: string; fg: string }> = {
  moss: { bg: colors.mossSoft, fg: colors.moss },
  rust: { bg: colors.rustSoft, fg: colors.rust },
  gold: { bg: colors.goldSoft, fg: '#8A6A24' },
  neutral: { bg: colors.sage, fg: colors.slateMuted },
};

export const statusToTone = (status: string): Tone => {
  switch (status) {
    case 'present':
    case 'paid':
    case 'reviewed':
      return 'moss';
    case 'absent':
    case 'overdue':
    case 'open':
      return 'rust';
    case 'late':
    case 'due':
    case 'pending':
    case 'excused':
      return 'gold';
    default:
      return 'neutral';
  }
};

export const Badge: React.FC<{ label: string; tone?: Tone }> = ({ label, tone }) => {
  const resolved = tone ?? statusToTone(label);
  const { bg, fg } = toneStyles[resolved];
  return (
    <View style={[styles.badge, { backgroundColor: bg }]}>
      <Text style={[styles.label, { color: fg }]}>{label.toUpperCase()}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderRadius: radius.pill,
    alignSelf: 'flex-start',
  },
  label: {
    fontFamily: type.mono,
    fontSize: 10,
    letterSpacing: 0.6,
  },
});
