import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';

export const StatCard: React.FC<{ label: string; value: string; accent?: string }> = ({
  label,
  value,
  accent = colors.ink,
}) => (
  <View style={styles.card}>
    <Text style={[styles.value, { color: accent }]}>{value}</Text>
    <Text style={styles.label}>{label}</Text>
  </View>
);

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.rule,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    marginRight: spacing.sm,
  },
  value: {
    fontFamily: type.mono,
    fontSize: fontSize.xl,
  },
  label: {
    fontFamily: type.body,
    fontSize: fontSize.xs,
    color: colors.slateMuted,
    marginTop: 4,
  },
});
