import React from 'react';
import { ScrollView, StyleSheet, View, ViewStyle } from 'react-native';
import { colors, spacing } from '@/theme/tokens';

export const ScreenContainer: React.FC<{ children: React.ReactNode; scroll?: boolean; style?: ViewStyle }> = ({
  children,
  scroll = true,
  style,
}) => {
  if (!scroll) {
    return <View style={[styles.container, style]}>{children}</View>;
  }
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={style}>{children}</View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.paper },
  content: { paddingHorizontal: spacing.lg, paddingBottom: spacing.xxl, paddingTop: spacing.md },
});
