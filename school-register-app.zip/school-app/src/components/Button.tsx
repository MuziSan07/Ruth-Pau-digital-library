import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ViewStyle } from 'react-native';
import { colors, type, fontSize, radius, spacing } from '@/theme/tokens';

interface ButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'ghost';
  style?: ViewStyle;
}

export const Button: React.FC<ButtonProps> = ({ label, onPress, variant = 'primary', style }) => (
  <TouchableOpacity
    style={[styles.base, variantStyles[variant], style]}
    onPress={onPress}
    activeOpacity={0.75}
  >
    <Text style={[styles.text, variant === 'primary' ? styles.textOnDark : styles.textOnLight]}>{label}</Text>
  </TouchableOpacity>
);

const variantStyles = StyleSheet.create({
  primary: { backgroundColor: colors.ink },
  secondary: { backgroundColor: colors.white, borderWidth: 1, borderColor: colors.ink },
  ghost: { backgroundColor: 'transparent' },
});

const styles = StyleSheet.create({
  base: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: { fontFamily: type.bodySemiBold, fontSize: fontSize.md },
  textOnDark: { color: colors.paper },
  textOnLight: { color: colors.ink },
});
