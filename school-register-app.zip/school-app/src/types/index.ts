export type Role = 'admin' | 'teacher' | 'parent';

export interface User {
  id: string;
  name: string;
  role: Role;
  avatarInitials: string;
  email: string;
}

export interface Teacher extends User {
  role: 'teacher';
  subjectsTaught: string[]; // subject ids this teacher teaches (can span classes)
  isClassTeacherOf?: string; // class id — a teacher is class-teacher of AT MOST one class
  monthlySalary: number;
  salaryStatus: 'paid' | 'pending';
}

export interface Student {
  id: string;
  name: string;
  classId: string;
  rollNo: number;
  parentId: string;
  feeStatus: 'paid' | 'due' | 'overdue';
  feeAmountDue: number;
}

export interface Parent extends User {
  role: 'parent';
  childIds: string[];
}

export interface SchoolClass {
  id: string;
  name: string; // e.g. "Grade 8 - A"
  classTeacherId: string; // exactly one class teacher
  subjectTeacherIds: Record<string, string>; // subjectId -> teacherId
  studentIds: string[];
}

export interface Subject {
  id: string;
  name: string;
}

export type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused';

export interface AttendanceRecord {
  id: string;
  classId: string;
  date: string; // ISO date
  markedBy: string; // teacherId
  entries: Record<string, AttendanceStatus>; // studentId -> status
}

export type AssessmentType = 'quiz' | 'test' | 'midterm' | 'final';

export interface Assessment {
  id: string;
  classId: string;
  subjectId: string;
  title: string;
  type: AssessmentType;
  date: string;
  maxMarks: number;
  createdBy: string; // teacherId
}

export interface AssessmentResult {
  assessmentId: string;
  studentId: string;
  marksObtained: number;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  category: 'exam' | 'holiday' | 'event' | 'meeting' | 'deadline';
  audience: 'all' | Role;
  description?: string;
}

export interface FeedbackEntry {
  id: string;
  fromId: string;
  fromRole: Role;
  fromName: string;
  toRole: Role | 'all';
  subject: string;
  message: string;
  date: string;
  status: 'open' | 'reviewed';
}

export interface FeeRecord {
  id: string;
  studentId: string;
  term: string;
  amount: number;
  status: 'paid' | 'due' | 'overdue';
  dueDate: string;
}

export interface SalaryRecord {
  id: string;
  teacherId: string;
  month: string;
  amount: number;
  status: 'paid' | 'pending';
}
