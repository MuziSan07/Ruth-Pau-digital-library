import React, { createContext, useContext, useMemo, useState } from 'react';
import { Role } from '@/types';
import * as api from '@/services/api';

interface AuthedUser {
  id: string;
  name: string;
  role: Role;
  avatarInitials: string;
}

interface AuthContextValue {
  user: AuthedUser | null;
  login: (role: Role, userId: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthedUser | null>(null);

  const login = (role: Role, userId: string) => {
    if (role === 'admin') {
      const admin = api.getAdmin();
      setUser({ id: admin.id, name: admin.name, role: 'admin', avatarInitials: admin.avatarInitials });
    } else if (role === 'teacher') {
      const teacher = api.getTeacherById(userId);
      if (teacher) setUser({ id: teacher.id, name: teacher.name, role: 'teacher', avatarInitials: teacher.avatarInitials });
    } else {
      const parent = api.getParentById(userId);
      if (parent) setUser({ id: parent.id, name: parent.name, role: 'parent', avatarInitials: parent.avatarInitials });
    }
  };

  const logout = () => setUser(null);

  const value = useMemo(() => ({ user, login, logout }), [user]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
